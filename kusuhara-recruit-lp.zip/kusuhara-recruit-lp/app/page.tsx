import { ApplicationForm } from "@/components/ApplicationForm";
import { FaqAccordion } from "@/components/FaqAccordion";
import { ImageBlock } from "@/components/ImageBlock";
import { MobileFixedCta, SiteHeader } from "@/components/SiteHeader";
import { SectionHeading } from "@/components/SectionHeading";
import type { FaqItem, FeatureCard, GalleryItem, Requirement, Stat, Voice } from "@/types/recruit";

const features: FeatureCard[] = [
  {
    title: "未経験から、手順を覚えていける",
    body: "はじめから完璧である必要はありません。作業の流れ、安全面、品質の見方を、現場で一つずつ確認しながら覚えていける環境を整えています。",
    image: "/images/work-01.jpg",
    alt: "製造現場で作業の手順を確認する様子"
  },
  {
    title: "チームで支え合う現場",
    body: "一人で抱え込まず、声をかけ合いながら進めることを大切にしています。小さな違和感を共有できる関係性が、安心して働ける現場をつくります。",
    image: "/images/work-02.jpg",
    alt: "チームで現場の確認をする様子"
  },
  {
    title: "地域に根ざした安定した仕事",
    body: "暮らしに近い製品づくりを通じて、地域の生活や産業を支えています。派手さよりも、毎日を丁寧に積み重ねる仕事です。",
    image: "/images/work-03.jpg",
    alt: "地域に根ざした工場の外観や作業風景"
  }
];

const gallery: GalleryItem[] = [
  {
    image: "/images/work-01.jpg",
    alt: "自然光の入る工場内で作業する手元",
    caption: "手元の確認を重ねながら、品質を守る。",
    wide: true
  },
  {
    image: "/images/work-02.jpg",
    alt: "作業場で先輩と後輩が確認する様子",
    caption: "分からないことを、その場で聞ける距離感。"
  },
  {
    image: "/images/people-01.jpg",
    alt: "働く人の自然な横顔",
    caption: "無理に飾らない、自然な表情がある職場。"
  },
  {
    image: "/images/location.jpg",
    alt: "勤務地周辺の落ち着いた風景",
    caption: "地域の暮らしの中で、長く働ける場所。"
  }
];

const voices: Voice[] = [
  {
    name: "Aさん",
    role: "製造スタッフ",
    comment:
      "最初は専門知識がなく不安でしたが、手順を見ながら少しずつ覚えられました。困った時に声をかけやすいのが助かっています。",
    image: "/images/people-01.jpg"
  },
  {
    name: "Bさん",
    role: "品質確認",
    comment:
      "毎日の仕事は地道ですが、自分の確認が製品の安心につながっていると感じます。落ち着いて働きたい人には合う職場だと思います。",
    image: "/images/people-02.jpg"
  },
  {
    name: "Cさん",
    role: "現場サポート",
    comment:
      "派手な仕事ではありませんが、チームで段取りを整えて一日を進めていく感覚があります。地域で腰を据えて働ける安心感があります。"
  }
];

const stats: Stat[] = [
  { value: "100年", label: "続くものづくり", note: "地域とともに積み重ねてきた歴史" },
  { value: "未経験可", label: "応募条件", note: "経験よりも、丁寧に学ぶ姿勢を重視" },
  { value: "安芸高田", label: "勤務地", note: "車通勤を想定した地域密着の働き方" },
  { value: "見学OK", label: "応募前相談", note: "仕事内容や現場を確認してから検討可能" },
  { value: "複数職種", label: "募集職種", note: "製造・品質・事務など状況に応じて相談" },
  { value: "チーム制", label: "働き方", note: "声をかけ合い、確認しながら進める現場" }
];

const requirements: Requirement[] = [
  { label: "募集職種", body: "製造スタッフ、品質確認、現場サポート、事務など。募集状況により変動します。" },
  { label: "仕事内容", body: "製品づくりに関わる作業、検品、資材準備、記録、現場内の確認業務など。" },
  { label: "勤務地", body: "広島県安芸高田市エリア。詳細住所・配属先は選考時にご案内します。" },
  { label: "雇用形態", body: "正社員・パートなど、募集職種により異なります。希望の働き方があればご相談ください。" },
  { label: "勤務時間", body: "日勤を基本に、職種や工程により異なります。詳細は面談・見学時に確認できます。" },
  { label: "休日", body: "会社カレンダーに準じます。家庭や生活との両立についても事前にご相談ください。" },
  { label: "給与", body: "経験・職種・雇用形態を踏まえて決定します。具体的な条件は選考時にご案内します。" },
  { label: "福利厚生", body: "社会保険、通勤に関する制度、休暇制度など。詳細は雇用形態により異なります。" },
  { label: "選考フロー", body: "応募または相談 → 担当者連絡 → 職場見学・面談 → 条件確認 → 選考結果のご連絡。" }
];

const faqs: FaqItem[] = [
  {
    question: "未経験でも応募できますか？",
    answer:
      "応募できます。専門知識よりも、手順を確認しながら丁寧に作業できることを大切にしています。経験が必要な職種は、募集時に明記します。"
  },
  {
    question: "職場見学はできますか？",
    answer:
      "可能です。応募前に仕事内容や現場の雰囲気を確認したい方は、フォームで「職場見学したい」を選んでください。"
  },
  {
    question: "車通勤はできますか？",
    answer:
      "車通勤を想定しています。通勤方法や駐車場などの詳細は、見学・面談時にご案内します。"
  },
  {
    question: "応募前に相談できますか？",
    answer:
      "できます。いきなり応募するのが不安な方は、仕事内容、働き方、見学希望などを事前に相談できます。"
  },
  {
    question: "選考にはどれくらい時間がかかりますか？",
    answer:
      "応募内容や日程調整によりますが、まずは担当者より連絡し、見学や面談の流れをご案内します。急ぎの場合はメッセージ欄にご記入ください。"
  }
];

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main id="top" className="pb-24 sm:pb-0">
        <HeroSection />
        <IntroSection />
        <WorkSection />
        <GallerySection />
        <VoiceSection />
        <StatsSection />
        <RequirementsSection />
        <FaqSection />
        <ApplicationSection />
      </main>
      <MobileFixedCta />
    </>
  );
}

function HeroSection() {
  return (
    <section className="relative overflow-hidden px-4 pt-24 sm:px-6 sm:pt-32 lg:px-8" aria-labelledby="hero-title">
      <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.88fr_1.12fr] lg:items-end">
        <div className="relative z-10 pb-2 lg:pb-16">
          <div className="mb-7 inline-flex items-center gap-3 rounded-full border border-brand-line bg-white px-4 py-2 shadow-sm">
            <span className="h-2.5 w-2.5 rounded-full bg-brand-red" aria-hidden="true" />
            <span className="text-xs font-bold tracking-[0.22em] text-brand-muted">
              RECRUITMENT
            </span>
          </div>
          <h1
            id="hero-title"
            className="text-balance text-4xl font-semibold leading-[1.08] tracking-[-0.055em] text-brand-ink sm:text-6xl lg:text-7xl"
          >
            ここで働く日々が、
            <br />
            少しずつ誇りになる。
          </h1>
          <p className="mt-6 max-w-xl text-base leading-8 text-brand-muted sm:text-lg">
            派手ではないけれど、誰かの暮らしを支える仕事があります。人と人が支え合う現場で、あなたらしい一歩をはじめませんか。
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href="#application"
              className="inline-flex min-h-[3.25rem] items-center justify-center rounded-full bg-brand-blue px-7 py-4 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2"
            >
              見学・応募する
            </a>
            <a
              href="#work"
              className="inline-flex min-h-[3.25rem] items-center justify-center rounded-full border border-brand-line bg-white px-7 py-4 text-sm font-bold text-brand-ink transition hover:-translate-y-0.5 hover:border-brand-blue hover:text-brand-blue focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2"
            >
              仕事内容を見る
            </a>
          </div>

          <div className="mt-10 grid grid-cols-3 gap-3">
            {[
              ["見学", "応募前に相談OK"],
              ["地域", "安芸高田で働く"],
              ["現場", "未経験から相談可"]
            ].map(([title, body]) => (
              <div key={title} className="rounded-3xl border border-brand-line bg-white/82 p-4 shadow-sm backdrop-blur">
                <p className="text-lg font-semibold text-brand-ink sm:text-2xl">{title}</p>
                <p className="mt-2 text-xs leading-5 text-brand-muted sm:text-sm">{body}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative min-h-[34rem] overflow-hidden rounded-[2.2rem] bg-slate-100 shadow-soft sm:min-h-[42rem] lg:min-h-[46rem]">
          <ImageBlock
            src="/images/hero.jpg"
            alt="楠原壜罐詰工業株式会社で働く人の自然な作業風景"
            priority
            sizes="(min-width: 1024px) 58vw, 100vw"
            className="absolute inset-0 h-full w-full rounded-[2.2rem]"
            imageClassName="brightness-[0.94]"
            label="ファーストビュー写真"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/72 via-slate-950/25 to-transparent p-6 text-white sm:p-8">
            <p className="max-w-lg text-sm font-semibold leading-7 sm:text-base">
              写真は public/images/hero.jpg に配置。実際の現場写真へ差し替えるだけで、LP全体の印象が整います。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function IntroSection() {
  return (
    <section className="section-pad px-4 sm:px-6 lg:px-8" aria-labelledby="intro-title">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 rounded-[2.2rem] border border-brand-line bg-white p-6 shadow-card sm:p-10 lg:grid-cols-[0.78fr_1.22fr] lg:p-14">
          <div>
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.28em] text-brand-blue">
              Message
            </p>
            <h2 id="intro-title" className="text-3xl font-semibold leading-tight tracking-[-0.04em] text-brand-ink sm:text-4xl">
              まじめに、
              <br />
              ていねいに、
              <br />
              長く続く仕事を。
            </h2>
          </div>
          <div className="space-y-6 text-base leading-9 text-brand-muted sm:text-lg">
            <p>
              私たちが大切にしているのは、特別な才能よりも、目の前の仕事に誠実に向き合う姿勢です。毎日の確認、声かけ、段取りの積み重ねが、安心して届けられる製品につながっています。
            </p>
            <p>
              地域に根ざした会社だからこそ、働く人の生活も大切にしたい。職場の雰囲気や仕事内容を見てから考えたい方も、まずは見学や相談からはじめられます。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function WorkSection() {
  return (
    <section id="work" className="section-pad bg-white px-4 sm:px-6 lg:px-8" aria-labelledby="work-title">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Work"
          title="働くイメージが、自然に浮かぶ仕事。"
          description="仕事内容を大きく見せすぎず、でも小さく見せすぎない。現場で大切にしていることを、3つの視点でまとめました。"
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {features.map((feature) => (
            <article key={feature.title} className="rounded-[2rem] border border-brand-line bg-brand-paper p-4 shadow-sm">
              <ImageBlock
                src={feature.image}
                alt={feature.alt}
                className="aspect-[4/3] rounded-[1.5rem]"
                sizes="(min-width: 768px) 33vw, 100vw"
              />
              <div className="p-2 pt-6">
                <h3 className="text-xl font-semibold leading-8 tracking-[-0.03em] text-brand-ink">
                  {feature.title}
                </h3>
                <p className="mt-3 text-sm leading-7 text-brand-muted">
                  {feature.body}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function GallerySection() {
  return (
    <section id="gallery" className="section-pad px-4 sm:px-6 lg:px-8" aria-labelledby="gallery-title">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-[0.86fr_1.14fr] lg:items-end">
          <SectionHeading
            eyebrow="Photo Story"
            title="写真で見る、職場の空気。"
            description="作業の手元、確認する横顔、現場の距離感。写真を差し替えるだけで、会社らしさが伝わる構成にしています。"
          />
          <p className="max-w-xl text-sm leading-8 text-brand-muted lg:justify-self-end">
            集合写真よりも、働く手元・横顔・後ろ姿・自然な会話の瞬間を優先すると、採用LPとしての信頼感が出やすくなります。
          </p>
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-4 lg:auto-rows-[18rem]">
          {gallery.map((item) => (
            <figure
              key={item.caption}
              className={`group relative overflow-hidden rounded-photo bg-slate-100 shadow-card ${
                item.wide ? "lg:col-span-2 lg:row-span-2" : "lg:col-span-2"
              }`}
            >
              <ImageBlock
                src={item.image}
                alt={item.alt}
                className="h-[22rem] rounded-photo lg:h-full"
                imageClassName="transition duration-500 group-hover:scale-[1.03]"
                sizes={item.wide ? "(min-width: 1024px) 50vw, 100vw" : "(min-width: 1024px) 40vw, 100vw"}
              />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/72 to-transparent p-5 text-sm font-semibold leading-7 text-white">
                {item.caption}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function VoiceSection() {
  return (
    <section className="section-pad bg-white px-4 sm:px-6 lg:px-8" aria-labelledby="voice-title">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="People"
          title="働く人の声。"
          description="顔写真がある場合は差し替え可能。写真がない場合でも、コメントだけで温度感が出るカード設計です。"
        />
        <div className="mt-12 grid gap-5 lg:grid-cols-3">
          {voices.map((voice) => (
            <article key={voice.name} className="rounded-[2rem] border border-brand-line bg-brand-paper p-5 shadow-sm sm:p-6">
              {voice.image ? (
                <ImageBlock
                  src={voice.image}
                  alt={`${voice.name}の職場での自然な様子`}
                  className="mb-6 aspect-[5/4] rounded-[1.5rem]"
                  sizes="(min-width: 1024px) 33vw, 100vw"
                />
              ) : (
                <div className="mb-6 flex aspect-[5/4] items-end rounded-[1.5rem] bg-gradient-to-br from-blue-50 via-white to-slate-100 p-6">
                  <p className="text-xs font-bold uppercase tracking-[0.28em] text-brand-blue">
                    No portrait
                  </p>
                </div>
              )}
              <p className="text-sm font-bold text-brand-blue">{voice.role}</p>
              <h3 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-brand-ink">
                {voice.name}
              </h3>
              <p className="mt-4 text-sm leading-8 text-brand-muted">
                {voice.comment}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function StatsSection() {
  return (
    <section className="section-pad px-4 sm:px-6 lg:px-8" aria-labelledby="stats-title">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Data"
          title="数字とキーワードで見る。"
          description="細かな条件は募集時に変わります。ここでは、応募前に安心材料になる情報を短く整理しています。"
          align="center"
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {stats.map((stat) => (
            <div key={stat.label} className="rounded-[2rem] border border-brand-line bg-white p-6 text-center shadow-sm">
              <p className="text-3xl font-semibold tracking-[-0.05em] text-brand-ink sm:text-4xl">
                {stat.value}
              </p>
              <p className="mt-3 text-sm font-bold text-brand-blue">{stat.label}</p>
              <p className="mt-3 text-sm leading-7 text-brand-muted">{stat.note}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function RequirementsSection() {
  return (
    <section id="requirements" className="section-pad bg-white px-4 sm:px-6 lg:px-8" aria-labelledby="requirements-title">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading
              eyebrow="Job Description"
              title="募集要項。"
              description="横スクロールが出ないよう、スマホでも読みやすいカード型にしています。条件は確定情報に合わせて調整してください。"
            />
            <a
              href="#application"
              className="mt-8 inline-flex min-h-[3.25rem] items-center justify-center rounded-full bg-brand-red px-7 py-4 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-red focus-visible:ring-offset-2"
            >
              この内容で相談する
            </a>
          </div>

          <div className="grid gap-4">
            {requirements.map((item) => (
              <article key={item.label} className="rounded-3xl border border-brand-line bg-brand-paper p-5 shadow-sm sm:grid sm:grid-cols-[10rem_1fr] sm:gap-5 sm:p-6">
                <h3 className="text-sm font-bold text-brand-blue">{item.label}</h3>
                <p className="mt-3 text-sm leading-8 text-brand-muted sm:mt-0">
                  {item.body}
                </p>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FaqSection() {
  return (
    <section id="faq" className="section-pad px-4 sm:px-6 lg:px-8" aria-labelledby="faq-title">
      <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.82fr_1.18fr]">
        <SectionHeading
          eyebrow="FAQ"
          title="応募前の不安を、先に減らす。"
          description="見学・相談・未経験応募など、求職者が最初に気になりやすい内容をアコーディオンで整理しています。"
        />
        <FaqAccordion items={faqs} />
      </div>
    </section>
  );
}

function ApplicationSection() {
  return (
    <section id="application" className="section-pad bg-white px-4 sm:px-6 lg:px-8" aria-labelledby="application-title">
      <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
        <div>
          <SectionHeading
            eyebrow="Entry / Contact"
            title="見学・応募・相談はこちら。"
            description="まだ応募するか決めていない方も、まずは相談で大丈夫です。フォーム送信後、担当者よりご連絡します。"
          />
          <div className="mt-8 rounded-[2rem] border border-brand-line bg-brand-paper p-6">
            <p className="text-sm font-bold text-brand-ink">フォーム送信の設定</p>
            <p className="mt-3 text-sm leading-8 text-brand-muted">
              Formspreeを使う場合は、Vercelの環境変数に NEXT_PUBLIC_FORMSPREE_ENDPOINT を設定してください。未設定の場合は、フォーム上に設定案内が表示されます。
            </p>
          </div>
        </div>
        <ApplicationForm />
      </div>
    </section>
  );
}
