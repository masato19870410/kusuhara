import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://example.com"),
  title: "楠原壜罐詰工業株式会社 採用情報",
  description:
    "楠原壜罐詰工業株式会社の採用LP。働く人、職場の雰囲気、募集要項、見学・応募フォームをご案内します。",
  openGraph: {
    title: "楠原壜罐詰工業株式会社 採用情報",
    description:
      "派手ではないけれど、誰かの暮らしを支える仕事があります。職場見学・応募はこちらから。",
    url: "https://example.com",
    siteName: "楠原壜罐詰工業株式会社 採用情報",
    images: [
      {
        url: "/images/ogp.jpg",
        width: 1200,
        height: 630,
        alt: "楠原壜罐詰工業株式会社 採用情報"
      }
    ],
    locale: "ja_JP",
    type: "website"
  },
  twitter: {
    card: "summary_large_image",
    title: "楠原壜罐詰工業株式会社 採用情報",
    description:
      "人と現場と地域を支える仕事。職場見学・応募はこちらから。",
    images: ["/images/ogp.jpg"]
  }
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
