type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
};

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left"
}: SectionHeadingProps) {
  const alignment = align === "center" ? "mx-auto text-center" : "";

  return (
    <div className={`max-w-3xl ${alignment}`}>
      <p className="mb-3 text-xs font-bold uppercase tracking-[0.28em] text-brand-blue">
        {eyebrow}
      </p>
      <h2 className="text-balance text-3xl font-semibold leading-tight tracking-[-0.04em] text-brand-ink sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-5 text-base leading-8 text-brand-muted sm:text-lg">
          {description}
        </p>
      ) : null}
    </div>
  );
}
