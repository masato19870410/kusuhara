"use client";

import Image from "next/image";
import { useState } from "react";

type ImageBlockProps = {
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
  priority?: boolean;
  sizes?: string;
  label?: string;
};

export function ImageBlock({
  src,
  alt,
  className = "aspect-[4/3]",
  imageClassName = "",
  priority = false,
  sizes = "(min-width: 1024px) 50vw, 100vw",
  label = "写真を差し替え"
}: ImageBlockProps) {
  const [failed, setFailed] = useState(false);
  const hasPositionClass = /\b(absolute|fixed|relative|sticky)\b/.test(className);
  const positionClass = hasPositionClass ? "" : "relative";

  return (
    <div
      className={`${positionClass} overflow-hidden rounded-photo bg-gradient-to-br from-slate-100 via-white to-blue-50 shadow-card ${className}`}
    >
      {!failed ? (
        <Image
          src={src}
          alt={alt}
          fill
          priority={priority}
          sizes={sizes}
          className={`object-cover ${imageClassName}`}
          onError={() => setFailed(true)}
        />
      ) : (
        <div className="absolute inset-0 flex flex-col justify-between p-6">
          <div className="h-1.5 w-24 rounded-full bg-brand-blue" />
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-brand-blue">
              Photo placeholder
            </p>
            <p className="mt-3 max-w-xs text-sm leading-7 text-brand-muted">
              {label}: public{src} に写真を配置すると、この枠に表示されます。
            </p>
          </div>
          <div className="h-1.5 w-24 rounded-full bg-brand-red" />
        </div>
      )}
    </div>
  );
}
