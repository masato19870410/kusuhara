import Image from "next/image";

const navItems = [
  { label: "仕事内容", href: "#work" },
  { label: "職場の雰囲気", href: "#gallery" },
  { label: "募集要項", href: "#requirements" },
  { label: "FAQ", href: "#faq" },
  { label: "応募する", href: "#application" }
];

export function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/70 bg-white/86 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:h-20 sm:px-6 lg:px-8">
        <a
          href="#top"
          className="flex min-w-0 items-center gap-3 rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2"
          aria-label="楠原壜罐詰工業株式会社 採用LPの先頭へ"
        >
          <span className="relative h-9 w-44 shrink-0 sm:h-11 sm:w-56">
            <Image
              src="/images/logo.png"
              alt="楠原壜罐詰工業株式会社"
              fill
              priority
              sizes="(min-width: 640px) 224px, 176px"
              className="object-contain"
            />
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="主要ナビゲーション">
          {navItems.slice(0, 4).map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-4 py-2 text-sm font-semibold text-brand-muted transition hover:bg-blue-50 hover:text-brand-blue focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <a
          href="#application"
          className="hidden rounded-full bg-brand-blue px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2 sm:inline-flex"
        >
          応募する
        </a>
      </div>
    </header>
  );
}

export function MobileFixedCta() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-white/70 bg-white/92 p-3 shadow-[0_-16px_40px_rgba(15,23,42,0.10)] backdrop-blur-xl sm:hidden">
      <a
        href="#application"
        className="flex min-h-12 w-full items-center justify-center rounded-full bg-brand-red px-5 py-3 text-sm font-bold text-white shadow-sm transition active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-red focus-visible:ring-offset-2"
      >
        応募・見学する
      </a>
    </div>
  );
}
