"use client";

import { useState } from "react";
import type { FaqItem } from "@/types/recruit";

type FaqAccordionProps = {
  items: FaqItem[];
};

export function FaqAccordion({ items }: FaqAccordionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="space-y-3">
      {items.map((item, index) => {
        const isOpen = openIndex === index;
        const panelId = `faq-panel-${index}`;
        const buttonId = `faq-button-${index}`;

        return (
          <div
            key={item.question}
            className="overflow-hidden rounded-3xl border border-brand-line bg-white shadow-sm"
          >
            <button
              id={buttonId}
              type="button"
              aria-expanded={isOpen}
              aria-controls={panelId}
              onClick={() => setOpenIndex(isOpen ? null : index)}
              className="flex w-full items-center justify-between gap-5 px-5 py-5 text-left outline-none transition hover:bg-slate-50 focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2 sm:px-7"
            >
              <span className="text-base font-semibold leading-7 text-brand-ink">
                {item.question}
              </span>
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-brand-line text-xl text-brand-blue transition ${
                  isOpen ? "rotate-45 bg-blue-50" : "bg-white"
                }`}
                aria-hidden="true"
              >
                +
              </span>
            </button>
            <div
              id={panelId}
              role="region"
              aria-labelledby={buttonId}
              className={`${isOpen ? "block" : "hidden"}`}
            >
              <p className="border-t border-brand-line px-5 py-5 text-sm leading-8 text-brand-muted sm:px-7 sm:text-base">
                {item.answer}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
