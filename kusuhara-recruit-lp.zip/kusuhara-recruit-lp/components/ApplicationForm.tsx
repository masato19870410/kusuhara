"use client";

import { useMemo, useState, type FormEvent, type ReactNode } from "react";

type FormState = {
  name: string;
  email: string;
  phone: string;
  intent: string;
  preferredRole: string;
  message: string;
};

type FormErrors = Partial<Record<keyof FormState, string>>;

type SubmitState =
  | { type: "idle"; message: string }
  | { type: "loading"; message: string }
  | { type: "success"; message: string }
  | { type: "error"; message: string };

const initialFormState: FormState = {
  name: "",
  email: "",
  phone: "",
  intent: "",
  preferredRole: "",
  message: ""
};

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function ApplicationForm() {
  const endpoint = process.env.NEXT_PUBLIC_FORMSPREE_ENDPOINT;
  const [form, setForm] = useState<FormState>(initialFormState);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitState, setSubmitState] = useState<SubmitState>({
    type: "idle",
    message: ""
  });

  const isSubmitting = submitState.type === "loading";

  const canSubmit = useMemo(() => {
    return form.name.trim() !== "" && emailPattern.test(form.email) && form.intent !== "";
  }, [form.email, form.intent, form.name]);

  const updateField = (field: keyof FormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const validate = () => {
    const nextErrors: FormErrors = {};

    if (!form.name.trim()) {
      nextErrors.name = "お名前を入力してください。";
    }

    if (!form.email.trim()) {
      nextErrors.email = "メールアドレスを入力してください。";
    } else if (!emailPattern.test(form.email)) {
      nextErrors.email = "メールアドレスの形式を確認してください。";
    }

    if (!form.intent) {
      nextErrors.intent = "希望内容を選択してください。";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitState({ type: "idle", message: "" });

    if (!validate()) {
      setSubmitState({
        type: "error",
        message: "入力内容を確認してください。"
      });
      return;
    }

    if (!endpoint) {
      setSubmitState({
        type: "error",
        message:
          "送信先が未設定です。環境変数 NEXT_PUBLIC_FORMSPREE_ENDPOINT を設定してください。"
      });
      return;
    }

    try {
      setSubmitState({ type: "loading", message: "送信しています。" });

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify({
          company: "楠原壜罐詰工業株式会社 採用LP",
          ...form
        })
      });

      if (!response.ok) {
        throw new Error("Failed to submit form");
      }

      setForm(initialFormState);
      setErrors({});
      setSubmitState({
        type: "success",
        message:
          "送信しました。内容を確認のうえ、担当者よりご連絡します。"
      });
    } catch {
      setSubmitState({
        type: "error",
        message:
          "送信に失敗しました。時間をおいて再度お試しください。"
      });
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-[2rem] border border-brand-line bg-white p-5 shadow-soft sm:p-8 lg:p-10"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="お名前" htmlFor="name" required error={errors.name}>
          <input
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            value={form.name}
            onChange={(event) => updateField("name", event.target.value)}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "name-error" : undefined}
            className="form-input"
            placeholder="例：山田 太郎"
          />
        </Field>

        <Field label="メールアドレス" htmlFor="email" required error={errors.email}>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "email-error" : undefined}
            className="form-input"
            placeholder="example@example.com"
          />
        </Field>

        <Field label="電話番号" htmlFor="phone" error={errors.phone}>
          <input
            id="phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            value={form.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            className="form-input"
            placeholder="090-0000-0000"
          />
        </Field>

        <Field label="希望内容" htmlFor="intent" required error={errors.intent}>
          <select
            id="intent"
            name="intent"
            value={form.intent}
            onChange={(event) => updateField("intent", event.target.value)}
            aria-invalid={Boolean(errors.intent)}
            aria-describedby={errors.intent ? "intent-error" : undefined}
            className="form-input"
          >
            <option value="">選択してください</option>
            <option value="応募したい">応募したい</option>
            <option value="職場見学したい">職場見学したい</option>
            <option value="まずは相談したい">まずは相談したい</option>
          </select>
        </Field>

        <div className="sm:col-span-2">
          <Field label="希望職種" htmlFor="preferredRole" error={errors.preferredRole}>
            <input
              id="preferredRole"
              name="preferredRole"
              type="text"
              value={form.preferredRole}
              onChange={(event) => updateField("preferredRole", event.target.value)}
              className="form-input"
              placeholder="例：製造スタッフ、品質管理、事務など"
            />
          </Field>
        </div>

        <div className="sm:col-span-2">
          <Field label="メッセージ" htmlFor="message" error={errors.message}>
            <textarea
              id="message"
              name="message"
              value={form.message}
              onChange={(event) => updateField("message", event.target.value)}
              className="form-input min-h-36 resize-y"
              placeholder="見学希望日、相談したいこと、気になる点などがあればご記入ください。"
            />
          </Field>
        </div>
      </div>

      <div className="mt-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs leading-6 text-brand-muted">
          必須項目を確認のうえ送信してください。送信後、担当者よりメールまたは電話でご連絡します。
        </p>
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex min-h-[3.25rem] items-center justify-center rounded-full bg-brand-blue px-8 py-4 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-blue focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {isSubmitting ? "送信中..." : "送信する"}
        </button>
      </div>

      {submitState.message ? (
        <div
          role="status"
          className={`mt-6 rounded-3xl px-5 py-4 text-sm leading-7 ${
            submitState.type === "success"
              ? "bg-emerald-50 text-emerald-800"
              : submitState.type === "error"
                ? "bg-red-50 text-red-700"
                : "bg-blue-50 text-brand-blue"
          }`}
        >
          {submitState.message}
        </div>
      ) : null}

      {!canSubmit ? (
        <p className="mt-4 text-xs leading-6 text-brand-muted">
          お名前・メールアドレス・希望内容の入力後に送信できます。
        </p>
      ) : null}
    </form>
  );
}

type FieldProps = {
  label: string;
  htmlFor: keyof FormState;
  required?: boolean;
  error?: string;
  children: ReactNode;
};

function Field({ label, htmlFor, required = false, error, children }: FieldProps) {
  const errorId = `${htmlFor}-error`;

  return (
    <div>
      <label htmlFor={htmlFor} className="mb-2 block text-sm font-bold text-brand-ink">
        {label}
        {required ? <span className="ml-2 text-brand-red">必須</span> : null}
      </label>
      {children}
      {error ? (
        <p id={errorId} className="mt-2 text-sm leading-6 text-red-600">
          {error}
        </p>
      ) : null}
    </div>
  );
}
