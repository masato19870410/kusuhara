# 楠原壜罐詰工業株式会社 採用LP

Next.js App Router + TypeScript + Tailwind CSS で実装した、写真主導の採用LPです。

ボタンのページ内スクロール、FAQアコーディオン、Formspree連携フォーム、スマホ下部固定CTAを実装しています。

## セットアップ方法

```bash
npm install
```

## 開発サーバー起動方法

```bash
npm run dev
```

ブラウザで `http://localhost:3000` を開きます。

## ビルド確認

```bash
npm run typecheck
npm run lint
npm run build
```

## Vercelデプロイ方法

1. このフォルダをGitHubリポジトリにpushする
2. Vercelで `Add New Project` を選ぶ
3. 対象のGitHubリポジトリをImportする
4. Framework Preset が `Next.js` になっていることを確認する
5. 必要に応じて環境変数を設定する
6. Deploy を押す

## 写真の差し替え方法

写真は `public/images/` に配置します。

使用しているファイル名は以下です。

- `public/images/logo.png`
- `public/images/hero.jpg`
- `public/images/work-01.jpg`
- `public/images/work-02.jpg`
- `public/images/work-03.jpg`
- `public/images/people-01.jpg`
- `public/images/people-02.jpg`
- `public/images/location.jpg`
- `public/images/ogp.jpg`

写真が未配置でも、ビルドは落ちません。表示時はプレースホルダーに切り替わります。

推奨写真は以下です。

- ファーストビュー：現場全体、自然光、働く人の後ろ姿や横顔
- 仕事の魅力：手元、確認作業、道具、先輩後輩の会話
- 職場写真：大きい写真1枚、小さい写真3枚
- 働く人の声：自然な表情、無理にポーズを取らない写真

人物・表情・服装・背景は加工しすぎず、トリミング・角丸・明るさ調整を中心にしてください。

## Formspree endpoint の設定方法

フォーム送信には Formspree を想定しています。

ローカルでは `.env.local` を作成し、以下を設定します。

```bash
NEXT_PUBLIC_FORMSPREE_ENDPOINT=https://formspree.io/f/xxxxxxx
```

Vercelでは以下で設定します。

1. Vercelの対象Projectを開く
2. Settings → Environment Variables を開く
3. Name に `NEXT_PUBLIC_FORMSPREE_ENDPOINT` を入力
4. Value に Formspree の endpoint URL を入力
5. Production / Preview / Development の必要な環境にチェック
6. Save
7. 再デプロイ

endpoint未設定の場合、フォーム送信時に以下の案内が表示されます。

「送信先が未設定です。環境変数 NEXT_PUBLIC_FORMSPREE_ENDPOINT を設定してください。」

## ボタン・フォームの動作確認方法

確認する導線は以下です。

- ヘッダーの `仕事内容` → 仕事内容セクションへ移動
- ヘッダーの `職場の雰囲気` → 写真セクションへ移動
- ヘッダーの `募集要項` → 募集要項へ移動
- ヘッダーの `FAQ` → FAQへ移動
- ヘッダーの `応募する` → 応募フォームへ移動
- ファーストビューの `見学・応募する` → 応募フォームへ移動
- ファーストビューの `仕事内容を見る` → 仕事内容へ移動
- スマホ下部固定CTA `応募・見学する` → 応募フォームへ移動
- 募集要項下の `この内容で相談する` → 応募フォームへ移動

フォーム確認は以下です。

1. 必須項目を空のまま送信し、エラー表示を確認
2. メールアドレス形式が不正な場合のエラーを確認
3. endpoint未設定時の案内を確認
4. Formspree endpoint設定後、送信成功メッセージを確認
5. Formspree側に送信データが届いていることを確認

## 主な実装ファイル

- `app/page.tsx`：LP本体
- `app/layout.tsx`：metadata / OGP設定
- `app/globals.css`：全体CSS / フォームCSS / スムーズスクロール
- `components/SiteHeader.tsx`：ヘッダー / スマホ固定CTA
- `components/ImageBlock.tsx`：next/image + プレースホルダー
- `components/FaqAccordion.tsx`：FAQアコーディオン
- `components/ApplicationForm.tsx`：応募フォーム / Formspree送信
- `components/SectionHeading.tsx`：セクション見出し
- `types/recruit.ts`：型定義
