export type FeatureCard = {
  title: string;
  body: string;
  image: string;
  alt: string;
};

export type GalleryItem = {
  image: string;
  alt: string;
  caption: string;
  wide?: boolean;
};

export type Voice = {
  name: string;
  role: string;
  comment: string;
  image?: string;
};

export type Stat = {
  value: string;
  label: string;
  note: string;
};

export type Requirement = {
  label: string;
  body: string;
};

export type FaqItem = {
  question: string;
  answer: string;
};
