import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./types/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: "#006CB8",
          red: "#E51B23",
          ink: "#1F2933",
          muted: "#637083",
          paper: "#F7FAFC",
          line: "#E2E8F0"
        }
      },
      boxShadow: {
        soft: "0 24px 70px rgba(15, 23, 42, 0.10)",
        card: "0 16px 45px rgba(15, 23, 42, 0.08)"
      },
      borderRadius: {
        photo: "2rem"
      }
    }
  },
  plugins: []
};

export default config;
